# Particle System:
personality: cant find it's mom????? WTF AM I SUPPOSED TO DO WITH THIS
Ideas:
- Boids: all acting in harmony with shades of blue, expect for one which is a different color that looks arround randomly not affected by the other system. Both are individual systems. but the big system is negatively repeled by the seeker boid. Yup thats it.
-Boids will fade in and out of existance depending on the distance they are located from the lost child, making said child the center of focus, with the environment fading in and out depending on them.